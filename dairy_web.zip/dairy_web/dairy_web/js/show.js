import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getDatabase,onValue,ref} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
const firebaseConfig = {
    apiKey: "AIzaSyArOKu4ouzSFKlHqCtjPeDhB7LQLSShKeo",
    authDomain: "first-867c5.firebaseapp.com",
    databaseURL: "https://first-867c5-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "first-867c5",
    storageBucket: "first-867c5.appspot.com",
    messagingSenderId: "492173949386",
    appId: "1:492173949386:web:fdad5496daca1b1638f733",
    measurementId: "G-Y346K2TBWW"
  };
  
  // Initialize Firebase
const app = initializeApp(firebaseConfig);
const db=getDatabase(app);
 //updating whenever any changes occurs in db
const comp=["ponlait","aavin","goodMorning","dodlaDairy","motherDairy","countryDelight"];
const compForId=["c1","c2","c3","c4","c5","c6"]
for(let k=0;k<comp.length;k++){

    // energy consumption//

    const engyRef=ref(db,`${comp[k]}/`);
    console.log(`energy${compForId[k]}`);
    const energyc=document.getElementById(`energy${compForId[k]}`);
    console.log(energyc);
    onValue(engyRef, (snapshot) => {
        const energy = snapshot.val();
        const power=energy.current*energy.voltage;
        //console.log(energy.current+" "+energy.voltage);
        energyc.innerText = power.toFixed(4)+" W"; // Adapt logic based on data type
      });

    const domainsInCp=["hygiene_d1","hygiene_d2","hygiene_d3","hygiene_d4","hygiene_d5"];
    const domainsForId=["d1","d2","d3","d4","d5"];
    for(let j=0;j<domainsInCp.length;j++){
        const dataPaths = [`${comp[k]}/${domainsInCp[j]}/temp`, `${comp[k]}/${domainsInCp[j]}/pressure`, `${comp[k]}/${domainsInCp[j]}/gas`, `${comp[k]}/${domainsInCp[j]}/flow`]; // Modify as needed

        const tempOfc1=document.getElementById(`tempOf${compForId[k]}${domainsForId[j]}`);
        const presOfc1=document.getElementById(`presOf${compForId[k]}${domainsForId[j]}`);
        const  gasOfc1=document.getElementById( `gasOf${compForId[k]}${domainsForId[j]}`);
        const flowOfc1=document.getElementById(`flowOf${compForId[k]}${domainsForId[j]}`);
        //console.log(`tempOf${compForId[0]}${domainsForId[j]}`);
        const elements = [tempOfc1, presOfc1, gasOfc1, flowOfc1]; 
        //console.log(dataPaths[0]);

        for (let i = 0; i < elements.length; i++) {
            
              const dataPath = dataPaths[i];
              const element = elements[i];
              //console.log(dataPath+" "+String(element));
              const dataRef = ref(db, dataPath);
            
              onValue(dataRef, (snapshot) => {
                const data = snapshot.val();
                element.innerHTML = `${getName(dataPath)} ${data} ${getUnit(dataPath)}`; // Adapt logic based on data type
              });
        }   
function getName(dataPath) {
    if (dataPath.includes("temp")) return "Temperature :";
    if (dataPath.includes("pressure")) return "Pressure :";
    if (dataPath.includes("gas")) return "Gas :";
    if (dataPath.includes("flow")) return "Flow :";
    // Add logic for other data types and units
  }
function getUnit(dataPath) {
  if (dataPath.includes("temp")) return "C";
  if (dataPath.includes("pressure")) return "Pa";
  if (dataPath.includes("gas")) return "cf";
  if (dataPath.includes("flow")) return "gpm";
}
}
}